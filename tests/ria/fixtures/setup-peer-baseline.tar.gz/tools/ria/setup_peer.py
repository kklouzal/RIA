"""Bounded setup RPC, separate from DSER and from measured native child ownership.

The network worker starts through fresh exec with one broker descriptor. It has
no controller objects, CA key, Docker descriptors or inherited parent heap.
Only locally registered exports and fixed dispatcher operations reach the
controller. TLS authenticates its pinned server; MACs authenticate both roles
and every reply in TLS and explicitly selected trusted-network mode.
"""

import base64
import ctypes
import hashlib
import hmac
import http.client
from http.server import BaseHTTPRequestHandler, HTTPServer
import ipaddress
import os
from pathlib import Path, PurePosixPath
import secrets
import signal
import shutil
import socket
import ssl
import stat
import struct
import subprocess
import sys
import tempfile
import threading
import time

from .identity import (
    ArtifactError,
    canonical as identity_canonical,
    check_json,
    digest,
    loads,
    open_regular,
    seal,
    sync_directory,
    verify_identity,
)
from .setup_journal import SetupJournal
from .setup_limits import (
    CHUNK,
    MAX_FILES,
    MAX_MESSAGE,
    MAX_NODES,
    MAX_RECEIPT,
    MAX_SETUP_SECONDS,
    MAX_TRANSFER_SECONDS,
    MAX_TREE,
)
from .setup_security import endpoint, validate_invitation

OPERATIONS = frozenset(
    {
        "offer",
        "client-offer",
        "commit-plan",
        "registration",
        "fixture-start",
        "probe",
        "native-fixture",
        "transport-fixture",
        "collect",
        "finalize",
        "launch",
        "health",
        "stop",
        "finish",
        "sign-csr",
    }
)


def canonical(value):
    check_json(value, max_nodes=MAX_NODES, max_depth=24)
    return identity_canonical(value)


class SetupNotReady(ArtifactError):
    """Only this classified environmental state may be polled by orchestration."""


def _timeout(value, maximum=MAX_TRANSFER_SECONDS):
    if type(value) not in (int, float) or not 0 < value <= maximum:
        raise ArtifactError("setup timeout is outside its positive bounded policy")
    return value


def _publish_tree(staging, output):
    # Linux is the declared setup target; never overwrite an unrelated directory.
    library = ctypes.CDLL(None, use_errno=True)
    rename = library.renameat2
    rename.argtypes = [
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_uint,
    ]
    rename.restype = ctypes.c_int
    if rename(-100, os.fsencode(staging), -100, os.fsencode(output), 1):
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code))
    sync_directory(output.parent)


def _private_directory(path):
    info = path.lstat()
    if (
        not stat.S_ISDIR(info.st_mode)
        or info.st_uid != os.geteuid()
        or stat.S_IMODE(info.st_mode) != 0o700
    ):
        raise ArtifactError("setup output requires an owned private real directory")


def _relative(value):
    if (
        not isinstance(value, str)
        or not 0 < len(value) <= 4096
        or "\\" in value
        or any(ord(c) < 32 or ord(c) == 127 for c in value)
    ):
        raise ArtifactError("invalid setup artifact path")
    path = PurePosixPath(value)
    if (
        path.is_absolute()
        or str(path) != value
        or len(path.parts) > 32
        or len(value.encode()) > 4095
        or any(part in (".", "..") or len(part.encode()) > 255 for part in path.parts)
    ):
        raise ArtifactError("setup artifact path must be canonical and relative")
    if path.suffix.lower() in (".key", ".pem", ".token") or path.name.startswith(
        ".env"
    ):
        raise ArtifactError("credentials must never be exported as setup artifacts")
    return path


def _file_state(info):
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns


class ExportTree:
    def __init__(self, name, path, *, max_bytes=MAX_TREE):
        if (
            not isinstance(name, str)
            or not name
            or len(name) > 96
            or any(
                c
                not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-"
                for c in name
            )
        ):
            raise ArtifactError("invalid registered export name")
        self.root = Path(path).absolute()
        if self.root.is_symlink() or not self.root.is_dir():
            raise ArtifactError("export must be an existing real directory")
        root_info = self.root.stat()
        self.root_identity = root_info.st_dev, root_info.st_ino
        if type(max_bytes) is not int or not 0 <= max_bytes <= MAX_TREE:
            raise ArtifactError("invalid registered export byte quota")
        self.states = {}
        files, total, pending, directories, manifest_bound = [], 0, [()], 0, 512
        while pending:
            directory = pending.pop()
            directories += 1
            if directories > MAX_FILES:
                raise ArtifactError("export directory population exceeds its bound")
            descriptor = self._directory(directory)
            try:
                with os.scandir(descriptor) as entries:
                    for entry in entries:
                        parts = (*directory, entry.name)
                        relative = "/".join(parts)
                        _relative(relative)
                        if entry.is_symlink():
                            raise ArtifactError("export contains a symlink")
                        if entry.is_dir(follow_symlinks=False):
                            if directories + len(pending) >= MAX_FILES:
                                raise ArtifactError(
                                    "export directory population exceeds its bound"
                                )
                            pending.append(parts)
                            continue
                        if (
                            not entry.is_file(follow_symlinks=False)
                            or len(files) >= MAX_FILES
                        ):
                            raise ArtifactError(
                                "export contains special files or too many files"
                            )
                        manifest_bound += 2 * len(relative.encode()) + 192
                        if manifest_bound > MAX_MESSAGE - 65536:
                            raise ArtifactError(
                                "setup export manifest exceeds its message envelope"
                            )
                        fd = os.open(
                            entry.name,
                            os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                            dir_fd=descriptor,
                        )
                        with os.fdopen(fd, "rb") as source:
                            before = os.fstat(source.fileno())
                            if not stat.S_ISREG(before.st_mode):
                                raise ArtifactError(
                                    "export leaf changed to a special file"
                                )
                            total += before.st_size
                            if total > max_bytes:
                                raise ArtifactError(
                                    "registered export exceeds its byte quota"
                                )
                            sha = hashlib.file_digest(source, "sha256").hexdigest()
                            if _file_state(before) != _file_state(
                                os.fstat(source.fileno())
                            ):
                                raise ArtifactError(
                                    "export changed during registration"
                                )
                        self.states[relative] = _file_state(before)
                        files.append(
                            {"path": relative, "bytes": before.st_size, "sha256": sha}
                        )
            finally:
                os.close(descriptor)
        if not files:
            raise ArtifactError("registered export is empty")
        self.manifest = seal(
            {
                "schema_revision": 1,
                "name": name,
                "files": sorted(files, key=lambda f: f["path"]),
                "total_bytes": total,
            }
        )

    def _directory(self, parts):
        directory = os.open(
            self.root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
        )
        try:
            info = os.fstat(directory)
            if (info.st_dev, info.st_ino) != self.root_identity:
                raise ArtifactError("export root changed")
            for part in parts:
                child = os.open(
                    part,
                    os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                    dir_fd=directory,
                )
                os.close(directory)
                directory = child
            return directory
        except BaseException:
            os.close(directory)
            raise

    def chunk(self, path, offset, length):
        parts = _relative(path).parts
        if (
            path not in self.states
            or type(offset) is not int
            or type(length) is not int
            or not 0 <= offset <= self.states[path][2]
            or not 0 < length <= CHUNK
        ):
            raise ArtifactError("chunk is outside its registered export")
        directory = self._directory(parts[:-1])
        try:
            fd = os.open(
                parts[-1],
                os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                dir_fd=directory,
            )
        finally:
            os.close(directory)
        with os.fdopen(fd, "rb") as source:
            if _file_state(os.fstat(source.fileno())) != self.states[path]:
                raise ArtifactError("export changed after registration")
            source.seek(offset)
            data = source.read(min(length, self.states[path][2] - offset))
            if _file_state(os.fstat(source.fileno())) != self.states[path]:
                raise ArtifactError("export changed during transfer")
        return data


def export_tree(name, path, *, max_bytes=MAX_TREE):
    return ExportTree(name, path, max_bytes=max_bytes)


def _manifest(manifest, max_bytes):
    if (
        not isinstance(manifest, dict)
        or set(manifest)
        != {"schema_revision", "name", "files", "total_bytes", "digest"}
        or type(manifest["schema_revision"]) is not int
        or manifest["schema_revision"] != 1
    ):
        raise ArtifactError("invalid export manifest")
    verify_identity(manifest)
    if (
        not isinstance(manifest["name"], str)
        or not manifest["name"]
        or len(manifest["name"]) > 96
        or any(
            c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-"
            for c in manifest["name"]
        )
    ):
        raise ArtifactError("invalid setup manifest name")
    files = manifest["files"]
    if (
        type(max_bytes) is not int
        or not isinstance(files, list)
        or not 0 < len(files) <= MAX_FILES
        or type(manifest["total_bytes"]) is not int
        or not 0 <= manifest["total_bytes"] <= max_bytes <= MAX_TREE
    ):
        raise ArtifactError("export manifest exceeds import quota")
    seen, directories, total = set(), set(), 0
    for item in files:
        if not isinstance(item, dict) or set(item) != {"path", "bytes", "sha256"}:
            raise ArtifactError("invalid export file entry")
        _relative(item["path"])
        if (
            item["path"] in seen
            or type(item["bytes"]) is not int
            or item["bytes"] < 0
            or not isinstance(item["sha256"], str)
            or len(item["sha256"]) != 64
            or any(c not in "0123456789abcdef" for c in item["sha256"])
        ):
            raise ArtifactError("duplicate or invalid export file")
        seen.add(item["path"])
        directories.update(str(p) for p in PurePosixPath(item["path"]).parents)
        if len(directories) > MAX_FILES:
            raise ArtifactError("setup manifest directory population exceeds its bound")
        total += item["bytes"]
    if total != manifest["total_bytes"] or any(
        str(parent) in seen for p in seen for parent in PurePosixPath(p).parents
    ):
        raise ArtifactError("export totals or file/directory paths conflict")
    return files


def import_tree(manifest, output, reader, *, max_bytes=MAX_TREE):
    """Publish a complete tree once; caller holds its private workspace process lock."""
    files = _manifest(manifest, max_bytes)
    total = manifest["total_bytes"]
    output = Path(output).absolute()
    _private_directory(output.parent)
    if output.exists() or output.is_symlink():
        raise ArtifactError("setup import destination must be new")
    if shutil.disk_usage(output.parent).free < total:
        raise ArtifactError("insufficient disk capacity for bounded setup import")
    staging = Path(tempfile.mkdtemp(prefix=".ria-import-", dir=output.parent))
    try:
        # Metadata cannot expose an incomplete model tree, even within staging.
        for item in sorted(
            files, key=lambda f: (f["path"] == "manifest.json", f["path"])
        ):
            target = staging.joinpath(*PurePosixPath(item["path"]).parts)
            target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            fd = os.open(
                target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600
            )
            sha, offset = hashlib.sha256(), 0
            with os.fdopen(fd, "wb") as stream:
                while offset < item["bytes"]:
                    length = min(CHUNK, item["bytes"] - offset)
                    data = reader(item["path"], offset, length)
                    if not isinstance(data, bytes) or len(data) != length:
                        raise ArtifactError(
                            "setup file transfer was truncated or oversized"
                        )
                    stream.write(data)
                    sha.update(data)
                    offset += length
                stream.flush()
                os.fsync(stream.fileno())
            if sha.hexdigest() != item["sha256"]:
                raise ArtifactError("setup file transfer hash mismatch")
        for directory in sorted(
            (p for p in staging.rglob("*") if p.is_dir()), reverse=True
        ):
            sync_directory(directory)
        sync_directory(staging)
        _publish_tree(staging, output)
        return manifest
    finally:
        if staging.exists():
            shutil.rmtree(staging)


class _Upload:
    """One locally allowed target; retries only continue the identical manifest.

    Progress is owned by this controller lifetime. A leftover staging directory
    after a crash fails closed and requires explicit local recovery; it is never
    mistaken for a completed proof tree or silently erased.
    """

    def __init__(self, output, manifest, maximum):
        self.files = {f["path"]: f for f in _manifest(manifest, maximum)}
        self.manifest, self.output = manifest, Path(output).absolute()
        _private_directory(self.output.parent)
        if self.output.exists() or self.output.is_symlink():
            raise ArtifactError("setup upload destination must be new")
        if shutil.disk_usage(self.output.parent).free < manifest["total_bytes"]:
            raise ArtifactError("insufficient capacity for bounded setup upload")
        self.staging = self.output.parent / (".ria-upload-" + manifest["digest"])
        self.staging.mkdir(mode=0o700, exist_ok=False)
        self.offsets, self.completed = dict.fromkeys(self.files, 0), False
        for name in self.files:
            path = self.staging.joinpath(*PurePosixPath(name).parts)
            path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with os.fdopen(
                os.open(
                    path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600
                ),
                "wb",
            ):
                pass

    def status(self):
        return {
            "digest": self.manifest["digest"],
            "offsets": dict(self.offsets),
            "completed": self.completed,
        }

    def chunk(self, path, offset, data):
        if (
            self.completed
            or not isinstance(path, str)
            or path not in self.files
            or type(offset) is not int
            or offset < 0
            or not isinstance(data, str)
            or len(data) > 4 * ((CHUNK + 2) // 3)
        ):
            raise ArtifactError("invalid setup upload chunk")
        try:
            raw = base64.b64decode(data, validate=True)
        except ValueError as error:
            raise ArtifactError("invalid setup upload encoding") from error
        if (
            not 0 < len(raw) <= CHUNK
            or offset > self.offsets[path]
            or offset + len(raw) > self.files[path]["bytes"]
        ):
            raise ArtifactError("setup upload chunk is outside declared file")
        target = self.staging.joinpath(*PurePosixPath(path).parts)
        with open(target, "r+b") as stream:
            stream.seek(offset)
            if offset < self.offsets[path]:
                if (
                    offset + len(raw) > self.offsets[path]
                    or stream.read(len(raw)) != raw
                ):
                    raise ArtifactError("setup upload retry has different bytes")
            else:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
                self.offsets[path] += len(raw)
        return self.status()

    def finish(self):
        if self.completed:
            return self.status()
        for name, item in self.files.items():
            if self.offsets[name] != item["bytes"]:
                raise ArtifactError("setup upload is incomplete")
            with open_regular(
                self.staging.joinpath(*PurePosixPath(name).parts)
            ) as stream:
                os.fsync(stream.fileno())
                if hashlib.file_digest(stream, "sha256").hexdigest() != item["sha256"]:
                    raise ArtifactError("setup upload file hash mismatch")
        for directory in sorted(
            (p for p in self.staging.rglob("*") if p.is_dir()), reverse=True
        ):
            sync_directory(directory)
        sync_directory(self.staging)
        _publish_tree(self.staging, self.output)
        self.completed = True
        return self.status()


def _send(stream, value):
    data = canonical(value)
    if len(data) > MAX_MESSAGE:
        raise ArtifactError("setup broker message exceeds its bound")
    stream.sendall(struct.pack("!I", len(data)) + data)


def _receive(stream):
    def exact(length):
        chunks = bytearray()
        while len(chunks) < length:
            data = stream.recv(length - len(chunks))
            if not data:
                raise EOFError("setup broker disconnected")
            chunks.extend(data)
        return bytes(chunks)

    length = struct.unpack("!I", exact(4))[0]
    if not 0 < length <= MAX_MESSAGE:
        raise ArtifactError("setup broker length exceeds its bound")
    return loads(
        exact(length), max_bytes=MAX_MESSAGE, max_nodes=MAX_NODES, max_depth=24
    )


def _mac(invitation, label, value):
    return hmac.new(
        bytes.fromhex(invitation["pair_secret"]),
        label.encode() + b"\x00" + canonical(value),
        hashlib.sha256,
    ).hexdigest()


class PeerServer:
    def __init__(
        self,
        invitation,
        security,
        dispatcher,
        exports=None,
        journal=None,
        *,
        worker_uid=10001,
        worker_gid=10001,
        timeout=30,
    ):
        self.invitation = validate_invitation(invitation)
        if security.invitation != invitation or security.role != "expert":
            raise ArtifactError(
                "peer server security differs from its fixed invitation"
            )
        self.security, self.dispatcher = security, dispatcher
        self.exports = dict(exports or {})
        self.journal = journal or SetupJournal(security.directory / "journal")
        self.worker_uid, self.worker_gid, self.timeout = (
            worker_uid,
            worker_gid,
            _timeout(timeout),
        )
        if worker_uid != 10001 or worker_gid != 10001:
            raise ArtifactError(
                "setup requires a privileged controller and exact isolated UID/GID10001 worker"
            )
        self.process = self.broker = self.thread = None
        self.tasks, self.mutex = {}, threading.Lock()
        self.lifecycle = threading.Condition()
        self.inflight = None
        self.reply_failure = None
        self.task_errors = {}
        self.stopping = False
        self.imports = {}

    def submit(self, stepid, name, payload):
        with self.lifecycle:
            return self._operation(
                "submit", {"step_id": stepid, "name": name, "payload": payload}
            )

    def status(self, stepid):
        value = self.journal.status(stepid)
        with self.mutex:
            if stepid in self.task_errors:
                raise ArtifactError(
                    "setup task durable failure: " + self.task_errors[stepid]
                )
        return value

    def allow_import(self, name, target, *, max_bytes=MAX_TREE):
        if (
            not isinstance(name, str)
            or not name
            or len(name) > 96
            or any(
                c
                not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-"
                for c in name
            )
            or type(max_bytes) is not int
            or not 0 <= max_bytes <= MAX_TREE
        ):
            raise ArtifactError("invalid locally allowed setup import")
        target = Path(target).absolute()
        _private_directory(target.parent)
        if name in self.imports or len(self.imports) >= 16:
            raise ArtifactError(
                "setup import name is immutable or population exhausted"
            )
        self.imports[name] = {"target": target, "maximum": max_bytes, "upload": None}

    def export_tree(self, name, path, *, max_bytes=MAX_TREE):
        if len(self.exports) >= 16 and name not in self.exports:
            raise ArtifactError("setup export population exhausted")
        tree = export_tree(name, path, max_bytes=max_bytes)
        if name in self.exports and self.exports[name].manifest != tree.manifest:
            raise ArtifactError("registered setup export is immutable")
        self.exports[name] = tree
        return tree.manifest

    def _operation(self, operation, payload):
        if self.stopping:
            raise ArtifactError("setup controller is stopping; new work rejected")
        if not isinstance(payload, dict):
            raise ArtifactError("setup operation requires an object payload")
        if operation in ("import-begin", "import-chunk", "import-finish"):
            keys = {
                "import-begin": {"name", "manifest"},
                "import-chunk": {"name", "digest", "path", "offset", "data"},
                "import-finish": {"name", "digest"},
            }
            if (
                set(payload) != keys[operation]
                or not isinstance(payload["name"], str)
                or payload["name"] not in self.imports
            ):
                raise ArtifactError("setup import is not locally authorized")
            target = self.imports[payload["name"]]
            if operation == "import-begin":
                manifest = payload["manifest"]
                if (
                    not isinstance(manifest, dict)
                    or manifest.get("name") != payload["name"]
                ):
                    raise ArtifactError(
                        "setup upload manifest has another artifact name"
                    )
                if target["upload"] is None:
                    target["upload"] = _Upload(
                        target["target"], manifest, target["maximum"]
                    )
                elif target["upload"].manifest != manifest:
                    raise ArtifactError("setup upload identity is immutable")
                return target["upload"].status()
            upload = target["upload"]
            if upload is None or payload["digest"] != upload.manifest["digest"]:
                raise ArtifactError("setup upload digest differs")
            if operation == "import-chunk":
                return upload.chunk(payload["path"], payload["offset"], payload["data"])
            return upload.finish()
        if operation == "export-manifest" and set(payload) == {"name"}:
            return self.exports[payload["name"]].manifest
        if operation == "export-chunk" and set(payload) == {
            "name",
            "path",
            "offset",
            "length",
        }:
            data = self.exports[payload["name"]].chunk(
                payload["path"], payload["offset"], payload["length"]
            )
            return {
                "data": base64.b64encode(data).decode("ascii"),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
        if operation == "status" and set(payload) == {"step_id"}:
            return self.status(payload["step_id"])
        if operation == "submit" and set(payload) == {"step_id", "name", "payload"}:
            if (
                not isinstance(payload["name"], str)
                or payload["name"] not in OPERATIONS
                or not isinstance(payload["payload"], dict)
            ):
                raise ArtifactError("unknown fixed setup task")
            with self.mutex:
                previous = self.journal.status(payload["step_id"])
                if previous["status"] == "unknown" and any(
                    t.is_alive() for t in self.tasks.values()
                ):
                    raise ArtifactError("another setup task already owns this role")
                value, created = self.journal.accept(
                    payload["step_id"], payload["name"], payload["payload"]
                )
                if created:
                    task = threading.Thread(
                        target=self._task, args=(payload,), daemon=False
                    )
                    self.tasks[payload["step_id"]] = task
                    task.start()
                return value
        if operation not in OPERATIONS:
            raise ArtifactError("unknown fixed setup operation")
        if operation == "sign-csr":
            if set(payload) != {"csr"}:
                raise ArtifactError("invalid client signing payload")
            return {"certificate": self.security.sign_client_csr(payload["csr"])}
        return self.dispatcher(operation, payload)

    def _task(self, payload):
        step = payload["step_id"]
        try:
            self.journal.transition(step, "running")
            result = self._operation(payload["name"], payload["payload"])
            # Validate receipt size before committing completion to disk.
            if len(canonical(result)) > MAX_RECEIPT - 65536:
                raise ArtifactError("setup result exceeds its bound")
            self.journal.transition(step, "completed", result=result)
        except Exception as error:
            try:
                self.journal.transition(step, "failed", error=str(error))
            except Exception as cleanup:
                with self.mutex:
                    self.task_errors[step] = (
                        str(error) + "; failed journal commit: " + str(cleanup)
                    )[:4096]

    def _serve_broker(self):
        stream = self.broker
        try:
            while not self.stopping:
                request = _receive(stream)
                if not isinstance(request, dict) or set(request) != {
                    "operation",
                    "payload",
                    "request_digest",
                }:
                    raise ArtifactError("invalid setup broker request")
                with self.lifecycle:
                    self.inflight = request["request_digest"]
                try:
                    result = {
                        "ok": True,
                        "result": self._operation(
                            request["operation"], request["payload"]
                        ),
                    }
                except Exception as error:
                    result = {
                        "ok": False,
                        "error": str(error)[:4096],
                        "code": "not_ready"
                        if isinstance(error, SetupNotReady)
                        else "failed",
                    }
                _send(
                    stream,
                    {"request_digest": request["request_digest"], "response": result},
                )
                receipt = _receive(stream)
                if receipt != {"reply_written": request["request_digest"]}:
                    raise ArtifactError(
                        "setup worker reply receipt has another association"
                    )
                with self.lifecycle:
                    self.inflight = None
                    self.lifecycle.notify_all()
        except (EOFError, OSError, ArtifactError):
            # Process health, rather than a fabricated result, exposes loss.
            self.stopping = True
        finally:
            with self.lifecycle:
                if self.inflight is not None:
                    self.reply_failure = (
                        "setup worker lost an in-flight authenticated response"
                    )
                self.inflight = None
                self.lifecycle.notify_all()

    def start(self):
        if os.geteuid() != 0:
            raise ArtifactError(
                "setup network isolation requires a privileged local controller"
            )
        if self.process is not None:
            raise ArtifactError("setup peer already started")
        docker = Path("/var/run/docker.sock")
        if docker.exists() and docker.stat().st_mode & stat.S_IWOTH:
            raise ArtifactError("setup refuses a world-writable Docker socket")
        parent, child = socket.socketpair()
        self.broker = parent
        self.process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "ria.setup_peer",
                "--worker-fd",
                str(child.fileno()),
            ],
            pass_fds=(child.fileno(),),
            close_fds=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env={
                "PATH": "/usr/local/bin:/usr/bin:/bin",
                "LANG": "C.UTF-8",
                "LC_ALL": "C.UTF-8",
                "PYTHONPATH": str(Path(__file__).resolve().parents[1]),
            },
        )
        child.close()
        parent.settimeout(self.timeout)
        try:
            _send(
                parent,
                {
                    "invitation": self.invitation,
                    "credentials": self.security.worker_credentials(),
                    "uid": self.worker_uid,
                    "gid": self.worker_gid,
                    "timeout": self.timeout,
                },
            )
            ready = _receive(parent)
            if ready != {"ready": True}:
                raise ArtifactError("setup network worker failed to initialize")
            parent.settimeout(None)
            self.thread = threading.Thread(target=self._serve_broker, daemon=False)
            self.thread.start()
            return self
        except Exception:
            try:
                self.close()
            except Exception:
                pass  # Preserve initialization failure; no tasks exist yet.
            raise

    def begin_close(self):
        """Stop admission; caller still owns every outstanding controller task."""
        deadline = time.monotonic() + self.timeout + 1
        with self.lifecycle:
            self.stopping = True
            while self.inflight is not None:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self.reply_failure = (
                        "setup response drain deadline elapsed; completion is ambiguous"
                    )
                    break
                self.lifecycle.wait(timeout=remaining)
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)
        if self.broker is not None:
            try:
                self.broker.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass  # An already disconnected broker owns no pending response.
            self.broker.close()
            self.broker = None

    def close(self, *, timeout=5):
        """Quiesce before releasing workspace; a timeout retains live ownership.

        Call begin_close, cancel/stop owned fixtures through local policy, then
        close. Raising here never grants permission to free those live resources.
        """
        deadline = time.monotonic() + _timeout(timeout)
        self.begin_close()
        if self.thread is not None:
            self.thread.join(timeout=max(0, deadline - time.monotonic()))
        for task in self.tasks.values():
            task.join(timeout=max(0, deadline - time.monotonic()))
        if (self.thread is not None and self.thread.is_alive()) or any(
            t.is_alive() for t in self.tasks.values()
        ):
            raise ArtifactError(
                "setup controller work remains owned; caller must quiesce its resources"
            )


class PeerClient:
    def __init__(self, invitation, peerendpoint=None, security=None, *, timeout=30):
        self.invitation = validate_invitation(invitation)
        self.host, self.port = endpoint(peerendpoint or invitation["endpoint"])
        if (self.host, self.port) != endpoint(invitation["endpoint"]):
            raise ArtifactError("setup peer endpoint differs from trusted invitation")
        self.security, self.timeout = security, _timeout(timeout)
        self.nonce, self.sequence, self.lock = (
            secrets.token_hex(32),
            0,
            threading.Lock(),
        )

    def _connection(self, timeout):
        if not self.invitation["tls_enabled"]:
            return http.client.HTTPConnection(self.host, self.port, timeout=timeout)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.minimum_version = ssl.TLSVersion.TLSv1_3
        context.check_hostname = False  # Exact invitation leaf pin is mandatory below.
        context.load_verify_locations(cadata=self.invitation["ca_pem"])
        return http.client.HTTPSConnection(
            self.host, self.port, timeout=timeout, context=context
        )

    def _exchange(self, path, payload, *, deadline=None):
        deadline = deadline or time.monotonic() + self.timeout
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise ArtifactError("setup request deadline elapsed")
        connection, timer = self._connection(remaining), None
        try:
            connection.connect()
            sock = connection.sock

            def expire():
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

            timer = threading.Timer(max(0, deadline - time.monotonic()), expire)
            timer.daemon = True
            timer.start()
            if (
                self.invitation["tls_enabled"]
                and hashlib.sha256(
                    connection.sock.getpeercert(binary_form=True)
                ).hexdigest()
                != self.invitation["server_leaf_sha256"]
            ):
                raise ArtifactError("setup TLS leaf differs from invitation pin")
            data = canonical(payload)
            if len(data) > MAX_MESSAGE:
                raise ArtifactError("setup request exceeds its bound")
            connection.request(
                "POST",
                path,
                body=data,
                headers={"Content-Type": "application/json", "Connection": "close"},
            )
            result = connection.getresponse()
            if (
                result.status != 200
                or result.getheader("Transfer-Encoding") is not None
            ):
                raise ArtifactError("setup peer rejected bounded request")
            lengths = result.headers.get_all("Content-Length", [])
            length = lengths[0] if len(lengths) == 1 else None
            if (
                length is None
                or not length.isdecimal()
                or not 0 < int(length) <= MAX_MESSAGE
            ):
                raise ArtifactError("invalid setup response length")
            raw = result.read(int(length) + 1)
            if len(raw) != int(length):
                raise ArtifactError("truncated or oversized setup response")
            if time.monotonic() >= deadline:
                raise ArtifactError("setup request deadline elapsed")
            return loads(raw, max_bytes=MAX_MESSAGE, max_nodes=MAX_NODES, max_depth=24)
        finally:
            if timer is not None:
                timer.cancel()
                timer.join()
            connection.close()

    def call(self, operation, payload, *, timeout=None):
        deadline = time.monotonic() + _timeout(
            self.timeout if timeout is None else timeout
        )
        if not self.lock.acquire(timeout=max(0, deadline - time.monotonic())):
            raise ArtifactError("setup client admission deadline elapsed")
        try:
            challenge = self._exchange("/challenge", {}, deadline=deadline)
            if (
                not isinstance(challenge, dict)
                or set(challenge) != {"body", "mac"}
                or not isinstance(challenge["mac"], str)
                or not hmac.compare_digest(
                    challenge["mac"],
                    _mac(self.invitation, "expert-challenge", challenge["body"]),
                )
            ):
                raise ArtifactError("setup peer challenge authentication failed")
            body = challenge["body"]
            if (
                not isinstance(body, dict)
                or set(body) != {"job_id", "tls_enabled", "server_nonce"}
                or body["job_id"] != self.invitation["job_id"]
                or body["tls_enabled"] is not self.invitation["tls_enabled"]
                or not isinstance(body["server_nonce"], str)
                or len(body["server_nonce"]) != 64
            ):
                raise ArtifactError("setup challenge has another job/mode")
            self.sequence += 1
            request = {
                "job_id": body["job_id"],
                "tls_enabled": body["tls_enabled"],
                "server_nonce": body["server_nonce"],
                "client_nonce": self.nonce,
                "sequence": self.sequence,
                "operation": operation,
                "payload": payload,
            }
            reply = self._exchange(
                "/rpc",
                {
                    "body": request,
                    "mac": _mac(self.invitation, "client-request", request),
                },
                deadline=deadline,
            )
            if (
                not isinstance(reply, dict)
                or set(reply) != {"body", "mac"}
                or not isinstance(reply["mac"], str)
                or not hmac.compare_digest(
                    reply["mac"],
                    _mac(self.invitation, "expert-response", reply["body"]),
                )
            ):
                raise ArtifactError("setup response authentication failed")
            response = reply["body"]
            if (
                not isinstance(response, dict)
                or set(response) != {"request_digest", "response"}
                or response["request_digest"] != digest(request)
            ):
                raise ArtifactError("setup response has another request association")
            result = response["response"]
            if not isinstance(result, dict) or result.get("ok") is not True:
                if isinstance(result, dict) and result.get("code") == "not_ready":
                    raise SetupNotReady(str(result.get("error", "setup not ready")))
                raise ArtifactError(
                    "setup operation failed: "
                    + str(
                        result.get("error", "unknown error")
                        if isinstance(result, dict)
                        else "invalid response"
                    )
                )
            return result["result"]
        finally:
            self.lock.release()

    def submit(self, stepid, name, payload):
        return self.call(
            "submit", {"step_id": stepid, "name": name, "payload": payload}
        )

    def status(self, stepid):
        return self.call("status", {"step_id": stepid})

    def wait(self, stepid, *, timeout=600):
        deadline = time.monotonic() + _timeout(timeout, maximum=MAX_SETUP_SECONDS)
        while time.monotonic() < deadline:
            value = self.call(
                "status",
                {"step_id": stepid},
                timeout=min(self.timeout, deadline - time.monotonic()),
            )
            if value["status"] == "completed":
                return value["result"]
            if value["status"] in ("failed", "unknown"):
                raise ArtifactError(
                    "setup task did not complete: "
                    + str(value.get("error", value["status"]))
                )
            time.sleep(min(0.1, max(0, deadline - time.monotonic())))
        raise ArtifactError(
            "setup task wait deadline elapsed; task ownership remains with controller"
        )

    def fetch_tree(self, name, output, *, max_bytes=MAX_TREE, timeout=3600):
        deadline = time.monotonic() + _timeout(timeout)

        def call(operation, payload):
            return self.call(
                operation,
                payload,
                timeout=min(self.timeout, max(0, deadline - time.monotonic())),
            )

        manifest = call("export-manifest", {"name": name})
        if manifest.get("name") != name:
            raise ArtifactError("setup export response has another artifact identity")

        def reader(path, offset, length):
            reply = call(
                "export-chunk",
                {"name": name, "path": path, "offset": offset, "length": length},
            )
            data = base64.b64decode(reply["data"], validate=True)
            if hashlib.sha256(data).hexdigest() != reply["sha256"]:
                raise ArtifactError("setup chunk hash mismatch")
            return data

        return import_tree(manifest, output, reader, max_bytes=max_bytes)

    def upload_tree(self, name, path, *, max_bytes=MAX_TREE, timeout=3600):
        deadline = time.monotonic() + _timeout(timeout)
        tree = export_tree(name, path, max_bytes=max_bytes)

        def call(operation, payload):
            return self.call(
                operation,
                payload,
                timeout=min(self.timeout, max(0, deadline - time.monotonic())),
            )

        progress = call("import-begin", {"name": name, "manifest": tree.manifest})
        if progress["digest"] != tree.manifest["digest"] or set(
            progress["offsets"]
        ) != set(tree.states):
            raise ArtifactError(
                "setup upload progress has another artifact association"
            )
        if progress["completed"] is True:
            return tree.manifest
        for item in tree.manifest["files"]:
            offset = progress["offsets"][item["path"]]
            if type(offset) is not int or not 0 <= offset <= item["bytes"]:
                raise ArtifactError("invalid setup upload offset")
            while offset < item["bytes"]:
                data = tree.chunk(
                    item["path"], offset, min(CHUNK, item["bytes"] - offset)
                )
                call(
                    "import-chunk",
                    {
                        "name": name,
                        "digest": tree.manifest["digest"],
                        "path": item["path"],
                        "offset": offset,
                        "data": base64.b64encode(data).decode("ascii"),
                    },
                )
                offset += len(data)
        result = call(
            "import-finish", {"name": name, "digest": tree.manifest["digest"]}
        )
        if (
            result["digest"] != tree.manifest["digest"]
            or result["completed"] is not True
        ):
            raise ArtifactError("setup upload was not completely published")
        return tree.manifest


def _worker(fd):
    broker = socket.socket(fileno=fd)
    config = _receive(broker)
    uid, gid = config["uid"], config["gid"]
    if os.geteuid() == 0:
        os.setgroups([])
        os.setgid(gid)
        os.setuid(uid)
    if os.geteuid() != uid or os.getegid() != gid or uid == 0 or os.getgroups():
        raise ArtifactError(
            "setup network worker must use an unprivileged exact identity"
        )
    if os.access("/var/run/docker.sock", os.W_OK):
        raise ArtifactError("setup network worker must have no Docker socket authority")
    invitation = validate_invitation(config["invitation"])
    host, port = endpoint(invitation["endpoint"])
    server_nonce, sessions = secrets.token_hex(32), {}

    def expired(signum, frame):
        raise TimeoutError("setup accepted request deadline elapsed")

    signal.signal(signal.SIGALRM, expired)

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.0"

        def log_message(self, *arguments):
            pass  # Never send credential-bearing parser input to diagnostics.

        def setup(self):
            self.request.settimeout(config["timeout"])
            super().setup()

        def do_POST(self):
            dispatched = False
            try:
                lengths = self.headers.get_all("Content-Length", [])
                if (
                    len(lengths) != 1
                    or not lengths[0].isdecimal()
                    or not 0 < int(lengths[0]) <= MAX_MESSAGE
                    or self.headers.get("Transfer-Encoding") is not None
                ):
                    raise ArtifactError("invalid setup request framing")
                data = self.rfile.read(int(lengths[0]))
                if len(data) != int(lengths[0]):
                    raise ArtifactError("truncated setup request")
                value = loads(
                    data, max_bytes=MAX_MESSAGE, max_nodes=MAX_NODES, max_depth=24
                )
                if self.path == "/challenge" and value == {}:
                    body = {
                        "job_id": invitation["job_id"],
                        "tls_enabled": invitation["tls_enabled"],
                        "server_nonce": server_nonce,
                    }
                    result = {
                        "body": body,
                        "mac": _mac(invitation, "expert-challenge", body),
                    }
                elif self.path == "/rpc":
                    if (
                        not isinstance(value, dict)
                        or set(value) != {"body", "mac"}
                        or not isinstance(value["mac"], str)
                        or not hmac.compare_digest(
                            value["mac"],
                            _mac(invitation, "client-request", value["body"]),
                        )
                    ):
                        raise ArtifactError("setup authentication failed")
                    body = value["body"]
                    fields = {
                        "job_id",
                        "tls_enabled",
                        "server_nonce",
                        "client_nonce",
                        "sequence",
                        "operation",
                        "payload",
                    }
                    if (
                        not isinstance(body, dict)
                        or set(body) != fields
                        or body["job_id"] != invitation["job_id"]
                        or body["tls_enabled"] is not invitation["tls_enabled"]
                        or body["server_nonce"] != server_nonce
                        or not isinstance(body["operation"], str)
                        or not isinstance(body["payload"], dict)
                    ):
                        raise ArtifactError("setup job/mode/session differs")
                    nonce, sequence = body["client_nonce"], body["sequence"]
                    if (
                        not isinstance(nonce, str)
                        or len(nonce) != 64
                        or any(c not in "0123456789abcdef" for c in nonce)
                        or type(sequence) is not int
                        or sequence <= sessions.get(nonce, 0)
                        or sequence > 9007199254740991
                    ):
                        raise ArtifactError("setup replay/sequence rejected")
                    if nonce not in sessions and len(sessions) >= 32:
                        raise ArtifactError("setup session population exhausted")
                    sessions[nonce] = sequence
                    dispatched = True
                    association = digest(body)
                    _send(
                        broker,
                        {
                            "operation": body["operation"],
                            "payload": body["payload"],
                            "request_digest": association,
                        },
                    )
                    response = _receive(broker)
                    if (
                        not isinstance(response, dict)
                        or set(response) != {"request_digest", "response"}
                        or response["request_digest"] != association
                    ):
                        os._exit(
                            1
                        )  # Retire an ambiguous broker; never associate a late reply to new work.
                    reply = response
                    result = {
                        "body": reply,
                        "mac": _mac(invitation, "expert-response", reply),
                    }
                else:
                    raise ArtifactError("unknown setup endpoint")
                encoded = canonical(result)
                if len(encoded) > MAX_MESSAGE:
                    raise ArtifactError("setup response exceeds its bound")
                self.send_response(200)
                self.send_header("Content-Length", str(len(encoded)))
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(encoded)
                self.wfile.flush()
                if dispatched:
                    _send(broker, {"reply_written": association})
            except (ValueError, TypeError, KeyError, EOFError, OSError):
                if dispatched:
                    os._exit(
                        1
                    )  # Parent retains tasks/fixtures until explicit local cleanup.
                self.send_error(400, "Setup request rejected")

    class Server(HTTPServer):
        address_family = (
            socket.AF_INET6
            if ipaddress.ip_address(host).version == 6
            else socket.AF_INET
        )
        request_queue_size = 2

        def get_request(self):
            connection, address = super().get_request()
            signal.setitimer(signal.ITIMER_REAL, config["timeout"])
            connection.settimeout(config["timeout"])
            if invitation["tls_enabled"]:
                try:
                    connection = self.context.wrap_socket(connection, server_side=True)
                except Exception:
                    signal.setitimer(signal.ITIMER_REAL, 0)
                    connection.close()
                    raise
            return connection, address

        def finish_request(self, request, address):
            try:
                super().finish_request(request, address)
            finally:
                signal.setitimer(signal.ITIMER_REAL, 0)

    with Server((host, port), Handler) as server:
        if invitation["tls_enabled"]:
            with tempfile.TemporaryDirectory(prefix="ria-setup-leaf-") as temporary:
                paths = []
                for name in ("certificate", "key"):
                    path = Path(temporary) / name
                    descriptor = os.open(
                        path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600
                    )
                    with os.fdopen(descriptor, "w") as file:
                        file.write(config["credentials"][name])
                    paths.append(path)
                server.context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                server.context.minimum_version = ssl.TLSVersion.TLSv1_3
                server.context.load_cert_chain(*map(str, paths))
        _send(broker, {"ready": True})
        server.serve_forever(poll_interval=0.1)


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] != "--worker-fd":
        raise SystemExit(2)
    _worker(int(sys.argv[2]))
